CARA MENJALANKAN (XAMPP)

1) Copy folder "rekap_kp" ke:
   C:\xampp\htdocs\rekap_kp

2) Start Apache + MySQL di XAMPP

3) Import database (phpMyAdmin):
   - Buat database: mpti_db
   - Import file SQL Anda (mpti_db.sql / isi tabel yang sama)

   Pastikan tabel ada:
   roles, users, mahasiswa, dosen, presensi, laporan, penilaian, jadwal_pengumuman, bimbingan, monitoring

4) Sesuaikan koneksi DB:
   config/db.php  (default: host=localhost user=root pass='' db=mpti_db)

5) Siapkan akun login (jika belum ada di tabel users):
   - roles harus berisi: admin, dosen, mahasiswa
   - users harus berisi minimal 1 user untuk masing-masing role
   - mahasiswa/dosen harus terhubung ke users melalui id_user

6) Buka:
   http://localhost/rekap_kp/

UPLOAD:
- Pastikan folder uploads ada: rekap_kp/uploads
- Jika upload gagal, cek permission folder (di Windows biasanya aman).

CATATAN:
- Password masih plaintext (sesuai struktur tugas kampus). Jika ingin hash, minta saya buatkan versi hash + migrasi.
