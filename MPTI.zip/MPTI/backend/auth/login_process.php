<?php
session_start();
require_once "../config/db.php";

$username = mysqli_real_escape_string($conn, $_POST['username'] ?? '');
$password = mysqli_real_escape_string($conn, $_POST['password'] ?? '');

$sql = "
  SELECT u.id_user, u.username, r.nama_role
  FROM users u
  JOIN roles r ON u.id_role = r.id_role
  WHERE u.username = '$username' AND u.password = '$password'
  LIMIT 1
";
$res = mysqli_query($conn, $sql);

if (!$res) {
    header("Location: ../index.php?err=" . urlencode("Query error: " . mysqli_error($conn)));
    exit;
}

$user = mysqli_fetch_assoc($res);

if (!$user) {
    header("Location: ../index.php?err=" . urlencode("Username atau password salah."));
    exit;
}

$_SESSION['id_user'] = $user['id_user'];
$_SESSION['username'] = $user['username'];
$_SESSION['role'] = $user['nama_role'];

// Logging sederhana (opsional)
@mysqli_query($conn, "INSERT INTO monitoring (aktivitas, id_user) VALUES ('Login', '{$user['id_user']}')");

if ($user['nama_role'] === 'admin') {
    header("Location: ../admin/dashboard.php");
} elseif ($user['nama_role'] === 'dosen') {
    header("Location: ../dosen/dashboard.php");
} else {
    header("Location: ../mahasiswa/dashboard.php");
}
exit;
?>
