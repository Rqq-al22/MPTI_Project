<?php
// Koneksi Database (sesuaikan user/pass jika berbeda)
$DB_HOST = "localhost";
$DB_USER = "root";
$DB_PASS = "";
$DB_NAME = "mpti_db";

$conn = mysqli_connect($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);

if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

// Pakai UTF-8
mysqli_set_charset($conn, "utf8mb4");
?>
