<?php
require_once "../includes/auth.php";
require_role('admin');
require_once "../config/db.php";

$page_title = "Dashboard Admin";
$asset_prefix = "../";
$menu_prefix = "../";
$logout_prefix = "../";

$cnt_mhs = mysqli_num_rows(mysqli_query($conn, "SELECT nim FROM mahasiswa"));
$cnt_dsn = mysqli_num_rows(mysqli_query($conn, "SELECT nidn FROM dosen"));
$cnt_lap = mysqli_num_rows(mysqli_query($conn, "SELECT id_laporan FROM laporan"));
$cnt_pre = mysqli_num_rows(mysqli_query($conn, "SELECT id_presensi FROM presensi"));
$cnt_peng = mysqli_num_rows(mysqli_query($conn, "SELECT id_jadwal FROM jadwal_pengumuman"));

$recent_laporan = mysqli_query($conn, "
  SELECT l.id_laporan, l.nim, m.nama AS nama_mhs, l.judul, l.tanggal_upload
  FROM laporan l
  LEFT JOIN mahasiswa m ON l.nim = m.nim
  ORDER BY l.id_laporan DESC
  LIMIT 7
");
include "../includes/layout_top.php";
?>
<?php include "../includes/sidebar.php"; ?>
<main class="main">
  <?php include "../includes/header.php"; ?>

  <div class="container">
    <div class="grid">
      <div class="card"><div class="card__title">Total Mahasiswa</div><div class="card__value"><?= $cnt_mhs ?></div><div class="badge">Data master</div></div>
      <div class="card"><div class="card__title">Total Dosen</div><div class="card__value"><?= $cnt_dsn ?></div><div class="badge">Data master</div></div>
      <div class="card"><div class="card__title">Laporan Masuk</div><div class="card__value"><?= $cnt_lap ?></div><div class="badge">Upload mahasiswa</div></div>
      <div class="card"><div class="card__title">Presensi Tercatat</div><div class="card__value"><?= $cnt_pre ?></div><div class="badge">Kehadiran</div></div>

      <div class="panel">
        <div class="panel__header">
          <div>
            <div class="panel__title">Aktivitas Terbaru</div>
            <div class="panel__desc">7 laporan terakhir yang diunggah mahasiswa</div>
          </div>
          <div class="actions">
            <a class="btn btn--ghost" href="pengumuman.php">Kelola Jadwal/Pengumuman (<?= $cnt_peng ?>)</a>
          </div>
        </div>

        <table class="table">
          <thead>
            <tr>
              <th>ID</th><th>Mahasiswa</th><th>Judul</th><th>Tanggal Upload</th>
            </tr>
          </thead>
          <tbody>
            <?php if ($recent_laporan && mysqli_num_rows($recent_laporan) > 0): ?>
              <?php while($r = mysqli_fetch_assoc($recent_laporan)): ?>
                <tr>
                  <td>#<?= esc($r['id_laporan']) ?></td>
                  <td><?= esc($r['nim']) ?><div class="small"><?= esc($r['nama_mhs'] ?? '-') ?></div></td>
                  <td><?= esc($r['judul']) ?></td>
                  <td><?= esc($r['tanggal_upload']) ?></td>
                </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr><td colspan="4" class="muted">Belum ada laporan.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

    </div>
  </div>
</main>
<?php include "../includes/layout_bottom.php"; ?>
