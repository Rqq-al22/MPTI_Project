<?php
require_once "../includes/auth.php";
require_role('admin');
require_once "../config/db.php";

$page_title = "Data Dosen";
$asset_prefix = "../";
$menu_prefix = "../";
$logout_prefix = "../";

$role_dsn = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id_role FROM roles WHERE nama_role='dosen' LIMIT 1"));
$ID_ROLE_DSN = $role_dsn ? (int)$role_dsn['id_role'] : 2;

$alert = null;

// Hapus
if (isset($_GET['delete']) && $_GET['delete'] !== '') {
    $nidn = mysqli_real_escape_string($conn, $_GET['delete']);
    $row = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id_user FROM dosen WHERE nidn='$nidn' LIMIT 1"));
    if ($row) {
        $id_user = (int)$row['id_user'];
        mysqli_query($conn, "DELETE FROM dosen WHERE nidn='$nidn'");
        mysqli_query($conn, "DELETE FROM users WHERE id_user='$id_user'");
        $alert = "Data dosen berhasil dihapus.";
    }
}

// Simpan
if (isset($_POST['save'])) {
    $mode = $_POST['mode'] ?? 'create';

    $nidn = mysqli_real_escape_string($conn, $_POST['nidn'] ?? '');
    $nama = mysqli_real_escape_string($conn, $_POST['nama'] ?? '');
    $keahlian = mysqli_real_escape_string($conn, $_POST['keahlian'] ?? '');

    if ($mode === 'create') {
        $username = mysqli_real_escape_string($conn, $_POST['username'] ?? '');
        $password = mysqli_real_escape_string($conn, $_POST['password'] ?? '');

        if ($username === '' || $password === '' || $nidn === '') {
            $alert = "Lengkapi NIDN, username, password.";
        } else {
            $ok = mysqli_query($conn, "INSERT INTO users (username, password, id_role) VALUES ('$username', '$password', '$ID_ROLE_DSN')");
            if (!$ok) {
                $alert = "Gagal membuat user: " . mysqli_error($conn);
            } else {
                $id_user = mysqli_insert_id($conn);
                $ok2 = mysqli_query($conn, "INSERT INTO dosen (nidn, nama, keahlian, id_user) VALUES ('$nidn', '$nama', '$keahlian', '$id_user')");
                if (!$ok2) {
                    mysqli_query($conn, "DELETE FROM users WHERE id_user='$id_user'");
                    $alert = "Gagal menyimpan dosen: " . mysqli_error($conn);
                } else {
                    $alert = "Dosen berhasil ditambahkan.";
                }
            }
        }
    } else {
        $id_user = (int)($_POST['id_user'] ?? 0);
        $ok = mysqli_query($conn, "UPDATE dosen SET nama='$nama', keahlian='$keahlian' WHERE nidn='$nidn'");
        if (!$ok) {
            $alert = "Gagal update dosen: " . mysqli_error($conn);
        } else {
            $newpass = trim($_POST['new_password'] ?? '');
            if ($newpass !== '' && $id_user > 0) {
                $newpass = mysqli_real_escape_string($conn, $newpass);
                mysqli_query($conn, "UPDATE users SET password='$newpass' WHERE id_user='$id_user'");
            }
            $alert = "Data dosen berhasil diperbarui.";
        }
    }
}

$edit = null;
if (isset($_GET['edit']) && $_GET['edit'] !== '') {
    $nidn = mysqli_real_escape_string($conn, $_GET['edit']);
    $edit = mysqli_fetch_assoc(mysqli_query($conn, "
      SELECT d.*, u.username
      FROM dosen d
      LEFT JOIN users u ON d.id_user = u.id_user
      WHERE d.nidn='$nidn' LIMIT 1
    "));
}

$list = mysqli_query($conn, "
  SELECT d.nidn, d.nama, d.keahlian, d.id_user, u.username
  FROM dosen d
  LEFT JOIN users u ON d.id_user = u.id_user
  ORDER BY d.nidn ASC
");

include "../includes/layout_top.php";
?>
<?php include "../includes/sidebar.php"; ?>
<main class="main">
  <?php include "../includes/header.php"; ?>

  <div class="container">
    <?php if ($alert): ?>
      <div class="alert alert--ok" style="margin-bottom:12px;"><?= esc($alert) ?></div>
    <?php endif; ?>

    <div class="grid">
      <div class="panel">
        <div class="panel__header">
          <div>
            <div class="panel__title"><?= $edit ? "Edit Dosen" : "Tambah Dosen" ?></div>
            <div class="panel__desc">Admin mengelola data dosen dan akun login.</div>
          </div>
        </div>

        <form class="form" method="POST">
          <input type="hidden" name="mode" value="<?= $edit ? "edit" : "create" ?>">
          <?php if ($edit): ?>
            <input type="hidden" name="id_user" value="<?= esc($edit['id_user']) ?>">
          <?php endif; ?>

          <div class="field">
            <div class="label">NIDN</div>
            <input class="input" name="nidn" value="<?= esc($edit['nidn'] ?? '') ?>" <?= $edit ? "readonly" : "" ?> required>
          </div>

          <div class="field">
            <div class="label">Nama</div>
            <input class="input" name="nama" value="<?= esc($edit['nama'] ?? '') ?>" required>
          </div>

          <div class="field">
            <div class="label">Keahlian</div>
            <input class="input" name="keahlian" value="<?= esc($edit['keahlian'] ?? '') ?>" placeholder="Contoh: Web Development">
          </div>

          <?php if (!$edit): ?>
            <div class="field">
              <div class="label">Username</div>
              <input class="input" name="username" required>
            </div>
            <div class="field">
              <div class="label">Password</div>
              <input class="input" name="password" required>
            </div>
          <?php else: ?>
            <div class="field">
              <div class="label">Username</div>
              <input class="input" value="<?= esc($edit['username'] ?? '-') ?>" readonly>
            </div>
            <div class="field">
              <div class="label">Reset Password (opsional)</div>
              <input class="input" name="new_password" placeholder="Kosongkan jika tidak diubah">
            </div>
          <?php endif; ?>

          <div class="field--full actions">
            <button class="btn btn--primary" name="save" type="submit"><?= $edit ? "Simpan Perubahan" : "Tambah Dosen" ?></button>
            <a class="btn btn--ghost" href="dosen.php">Reset Form</a>
          </div>
        </form>
      </div>

      <div class="panel">
        <div class="panel__header">
          <div>
            <div class="panel__title">Daftar Dosen</div>
            <div class="panel__desc">Klik Edit untuk mengubah data, atau Hapus untuk menghapus akun.</div>
          </div>
        </div>

        <table class="table">
          <thead>
            <tr>
              <th>NIDN</th><th>Nama</th><th>Keahlian</th><th>Akun</th><th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php if ($list && mysqli_num_rows($list)>0): ?>
              <?php while($r=mysqli_fetch_assoc($list)): ?>
                <tr>
                  <td><?= esc($r['nidn']) ?></td>
                  <td><?= esc($r['nama']) ?></td>
                  <td><?= esc($r['keahlian']) ?></td>
                  <td><?= esc($r['username'] ?? '-') ?></td>
                  <td>
                    <div class="actions">
                      <a class="btn btn--ghost" href="?edit=<?= urlencode($r['nidn']) ?>">Edit</a>
                      <a class="btn btn--danger" href="?delete=<?= urlencode($r['nidn']) ?>" onclick="return confirm('Hapus dosen ini?')">Hapus</a>
                    </div>
                  </td>
                </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr><td colspan="5" class="muted">Belum ada data dosen.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

    </div>
  </div>
</main>
<?php include "../includes/layout_bottom.php"; ?>
