<?php
require_once "../includes/auth.php";
require_role('admin');
require_once "../config/db.php";

$page_title = "Data Mahasiswa";
$asset_prefix = "../";
$menu_prefix = "../";
$logout_prefix = "../";

$role_mhs = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id_role FROM roles WHERE nama_role='mahasiswa' LIMIT 1"));
$ID_ROLE_MHS = $role_mhs ? (int)$role_mhs['id_role'] : 3;

$alert = null;

// Hapus
if (isset($_GET['delete']) && $_GET['delete'] !== '') {
    $nim = mysqli_real_escape_string($conn, $_GET['delete']);
    // ambil id_user dulu
    $row = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id_user FROM mahasiswa WHERE nim='$nim' LIMIT 1"));
    if ($row) {
        $id_user = (int)$row['id_user'];
        mysqli_query($conn, "DELETE FROM mahasiswa WHERE nim='$nim'");
        // hapus user juga (opsional)
        mysqli_query($conn, "DELETE FROM users WHERE id_user='$id_user'");
        $alert = "Data mahasiswa berhasil dihapus.";
    }
}

// Simpan (Tambah / Edit)
if (isset($_POST['save'])) {
    $mode = $_POST['mode'] ?? 'create';

    $nim = mysqli_real_escape_string($conn, $_POST['nim'] ?? '');
    $nama = mysqli_real_escape_string($conn, $_POST['nama'] ?? '');
    $jurusan = mysqli_real_escape_string($conn, $_POST['jurusan'] ?? '');
    $angkatan = (int)($_POST['angkatan'] ?? 0);

    if ($mode === 'create') {
        $username = mysqli_real_escape_string($conn, $_POST['username'] ?? '');
        $password = mysqli_real_escape_string($conn, $_POST['password'] ?? '');

        if ($username === '' || $password === '' || $nim === '') {
            $alert = "Lengkapi NIM, username, password.";
        } else {
            // buat user
            $ok = mysqli_query($conn, "INSERT INTO users (username, password, id_role) VALUES ('$username', '$password', '$ID_ROLE_MHS')");
            if (!$ok) {
                $alert = "Gagal membuat user: " . mysqli_error($conn);
            } else {
                $id_user = mysqli_insert_id($conn);
                $ok2 = mysqli_query($conn, "INSERT INTO mahasiswa (nim, nama, jurusan, angkatan, id_user) VALUES ('$nim', '$nama', '$jurusan', '$angkatan', '$id_user')");
                if (!$ok2) {
                    // rollback user
                    mysqli_query($conn, "DELETE FROM users WHERE id_user='$id_user'");
                    $alert = "Gagal menyimpan mahasiswa: " . mysqli_error($conn);
                } else {
                    $alert = "Mahasiswa berhasil ditambahkan.";
                }
            }
        }
    } else {
        $id_user = (int)($_POST['id_user'] ?? 0);
        $ok = mysqli_query($conn, "UPDATE mahasiswa SET nama='$nama', jurusan='$jurusan', angkatan='$angkatan' WHERE nim='$nim'");
        if (!$ok) {
            $alert = "Gagal update mahasiswa: " . mysqli_error($conn);
        } else {
            // reset password (opsional)
            $newpass = trim($_POST['new_password'] ?? '');
            if ($newpass !== '' && $id_user > 0) {
                $newpass = mysqli_real_escape_string($conn, $newpass);
                mysqli_query($conn, "UPDATE users SET password='$newpass' WHERE id_user='$id_user'");
            }
            $alert = "Data mahasiswa berhasil diperbarui.";
        }
    }
}

// Mode edit (ambil data)
$edit = null;
if (isset($_GET['edit']) && $_GET['edit'] !== '') {
    $nim = mysqli_real_escape_string($conn, $_GET['edit']);
    $edit = mysqli_fetch_assoc(mysqli_query($conn, "
      SELECT m.*, u.username
      FROM mahasiswa m
      LEFT JOIN users u ON m.id_user = u.id_user
      WHERE m.nim='$nim' LIMIT 1
    "));
}

$list = mysqli_query($conn, "
  SELECT m.nim, m.nama, m.jurusan, m.angkatan, m.id_user, u.username
  FROM mahasiswa m
  LEFT JOIN users u ON m.id_user = u.id_user
  ORDER BY m.angkatan DESC, m.nim ASC
");

include "../includes/layout_top.php";
?>
<?php include "../includes/sidebar.php"; ?>
<main class="main">
  <?php include "../includes/header.php"; ?>

  <div class="container">
    <?php if ($alert): ?>
      <div class="alert alert--ok" style="margin-bottom:12px;"><?= esc($alert) ?></div>
    <?php endif; ?>

    <div class="grid">
      <div class="panel" style="grid-column: span 12;">
        <div class="panel__header">
          <div>
            <div class="panel__title"><?= $edit ? "Edit Mahasiswa" : "Tambah Mahasiswa" ?></div>
            <div class="panel__desc">Admin mengelola data mahasiswa dan akun login.</div>
          </div>
        </div>

        <form class="form" method="POST">
          <input type="hidden" name="mode" value="<?= $edit ? "edit" : "create" ?>">
          <?php if ($edit): ?>
            <input type="hidden" name="id_user" value="<?= esc($edit['id_user']) ?>">
          <?php endif; ?>

          <div class="field">
            <div class="label">NIM</div>
            <input class="input" name="nim" value="<?= esc($edit['nim'] ?? '') ?>" <?= $edit ? "readonly" : "" ?> required>
          </div>

          <div class="field">
            <div class="label">Nama</div>
            <input class="input" name="nama" value="<?= esc($edit['nama'] ?? '') ?>" required>
          </div>

          <div class="field">
            <div class="label">Jurusan</div>
            <input class="input" name="jurusan" value="<?= esc($edit['jurusan'] ?? '') ?>" placeholder="Contoh: Informatika">
          </div>

          <div class="field">
            <div class="label">Angkatan</div>
            <input class="input" type="number" name="angkatan" value="<?= esc($edit['angkatan'] ?? '') ?>" placeholder="2022">
          </div>

          <?php if (!$edit): ?>
            <div class="field">
              <div class="label">Username</div>
              <input class="input" name="username" required>
            </div>
            <div class="field">
              <div class="label">Password</div>
              <input class="input" name="password" required>
            </div>
          <?php else: ?>
            <div class="field">
              <div class="label">Username</div>
              <input class="input" value="<?= esc($edit['username'] ?? '-') ?>" readonly>
            </div>
            <div class="field">
              <div class="label">Reset Password (opsional)</div>
              <input class="input" name="new_password" placeholder="Kosongkan jika tidak diubah">
            </div>
          <?php endif; ?>

          <div class="field--full actions">
            <button class="btn btn--primary" name="save" type="submit"><?= $edit ? "Simpan Perubahan" : "Tambah Mahasiswa" ?></button>
            <a class="btn btn--ghost" href="mahasiswa.php">Reset Form</a>
          </div>
        </form>
      </div>

      <div class="panel" style="grid-column: span 12;">
        <div class="panel__header">
          <div>
            <div class="panel__title">Daftar Mahasiswa</div>
            <div class="panel__desc">Klik Edit untuk mengubah data, atau Hapus untuk menghapus akun.</div>
          </div>
        </div>

        <table class="table">
          <thead>
            <tr>
              <th>NIM</th><th>Nama</th><th>Jurusan</th><th>Angkatan</th><th>Akun</th><th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php if ($list && mysqli_num_rows($list)>0): ?>
              <?php while($r=mysqli_fetch_assoc($list)): ?>
                <tr>
                  <td><?= esc($r['nim']) ?></td>
                  <td><?= esc($r['nama']) ?></td>
                  <td><?= esc($r['jurusan']) ?></td>
                  <td><?= esc($r['angkatan']) ?></td>
                  <td><?= esc($r['username'] ?? '-') ?></td>
                  <td>
                    <div class="actions">
                      <a class="btn btn--ghost" href="?edit=<?= urlencode($r['nim']) ?>">Edit</a>
                      <a class="btn btn--danger" href="?delete=<?= urlencode($r['nim']) ?>" onclick="return confirm('Hapus mahasiswa ini?')">Hapus</a>
                    </div>
                  </td>
                </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr><td colspan="6" class="muted">Belum ada data mahasiswa.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

    </div>
  </div>
</main>
<?php include "../includes/layout_bottom.php"; ?>
