<?php
require_once "../includes/auth.php";
require_role('admin');
require_once "../config/db.php";

$page_title = "Jadwal & Pengumuman";
$asset_prefix = "../";
$menu_prefix = "../";
$logout_prefix = "../";

$alert = null;

// delete
if (isset($_GET['delete']) && $_GET['delete'] !== '') {
  $id = (int)$_GET['delete'];
  mysqli_query($conn, "DELETE FROM jadwal_pengumuman WHERE id_jadwal='$id'");
  $alert = "Data berhasil dihapus.";
}

// save
if (isset($_POST['save'])) {
  $mode = $_POST['mode'] ?? 'create';
  $judul = mysqli_real_escape_string($conn, $_POST['judul'] ?? '');
  $deskripsi = mysqli_real_escape_string($conn, $_POST['deskripsi'] ?? '');
  $tanggal = mysqli_real_escape_string($conn, $_POST['tanggal'] ?? '');

  if ($mode === 'create') {
    mysqli_query($conn, "INSERT INTO jadwal_pengumuman (judul, deskripsi, tanggal) VALUES ('$judul', '$deskripsi', '$tanggal')");
    $alert = "Berhasil menambah jadwal/pengumuman.";
  } else {
    $id = (int)($_POST['id_jadwal'] ?? 0);
    mysqli_query($conn, "UPDATE jadwal_pengumuman SET judul='$judul', deskripsi='$deskripsi', tanggal='$tanggal' WHERE id_jadwal='$id'");
    $alert = "Berhasil memperbarui jadwal/pengumuman.";
  }
}

$edit = null;
if (isset($_GET['edit']) && $_GET['edit'] !== '') {
  $id = (int)$_GET['edit'];
  $edit = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM jadwal_pengumuman WHERE id_jadwal='$id'"));
}

$list = mysqli_query($conn, "SELECT * FROM jadwal_pengumuman ORDER BY tanggal DESC, id_jadwal DESC");

include "../includes/layout_top.php";
?>
<?php include "../includes/sidebar.php"; ?>
<main class="main">
  <?php include "../includes/header.php"; ?>

  <div class="container">
    <?php if ($alert): ?><div class="alert alert--ok" style="margin-bottom:12px;"><?= esc($alert) ?></div><?php endif; ?>

    <div class="grid">
      <div class="panel">
        <div class="panel__header">
          <div>
            <div class="panel__title"><?= $edit ? "Edit Jadwal/Pengumuman" : "Tambah Jadwal/Pengumuman" ?></div>
            <div class="panel__desc">Gunakan untuk jadwal, batas laporan, atau informasi penting lainnya.</div>
          </div>
        </div>

        <form class="form" method="POST">
          <input type="hidden" name="mode" value="<?= $edit ? "edit" : "create" ?>">
          <?php if ($edit): ?><input type="hidden" name="id_jadwal" value="<?= esc($edit['id_jadwal']) ?>"><?php endif; ?>

          <div class="field field--full">
            <div class="label">Judul</div>
            <input class="input" name="judul" value="<?= esc($edit['judul'] ?? '') ?>" required>
          </div>
          <div class="field field--full">
            <div class="label">Deskripsi</div>
            <textarea class="textarea" name="deskripsi" required><?= esc($edit['deskripsi'] ?? '') ?></textarea>
          </div>
          <div class="field">
            <div class="label">Tanggal</div>
            <input class="input" type="date" name="tanggal" value="<?= esc($edit['tanggal'] ?? date('Y-m-d')) ?>" required>
          </div>

          <div class="field field--full actions">
            <button class="btn btn--primary" name="save" type="submit"><?= $edit ? "Simpan Perubahan" : "Tambah" ?></button>
            <a class="btn btn--ghost" href="pengumuman.php">Reset Form</a>
          </div>
        </form>
      </div>

      <div class="panel">
        <div class="panel__header">
          <div>
            <div class="panel__title">Daftar Jadwal/Pengumuman</div>
            <div class="panel__desc">Terbaru akan tampil di atas.</div>
          </div>
        </div>

        <table class="table">
          <thead>
            <tr><th>Tanggal</th><th>Judul</th><th>Deskripsi</th><th>Aksi</th></tr>
          </thead>
          <tbody>
            <?php if ($list && mysqli_num_rows($list)>0): ?>
              <?php while($r=mysqli_fetch_assoc($list)): ?>
                <tr>
                  <td><?= esc($r['tanggal']) ?></td>
                  <td><?= esc($r['judul']) ?></td>
                  <td><?= esc($r['deskripsi']) ?></td>
                  <td>
                    <div class="actions">
                      <a class="btn btn--ghost" href="?edit=<?= $r['id_jadwal'] ?>">Edit</a>
                      <a class="btn btn--danger" href="?delete=<?= $r['id_jadwal'] ?>" onclick="return confirm('Hapus item ini?')">Hapus</a>
                    </div>
                  </td>
                </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr><td colspan="4" class="muted">Belum ada jadwal/pengumuman.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

    </div>
  </div>
</main>
<?php include "../includes/layout_bottom.php"; ?>
