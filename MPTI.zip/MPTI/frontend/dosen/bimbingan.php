<?php
require_once "../includes/auth.php";
require_role('dosen');
require_once "../config/db.php";

$page_title = "Bimbingan";
$asset_prefix = "../";
$menu_prefix = "../";
$logout_prefix = "../";

$id_user = (int)$_SESSION['id_user'];
$dosen = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM dosen WHERE id_user='$id_user' LIMIT 1"));
$nidn = $dosen['nidn'] ?? '';
if (!$nidn) { header("Location: dashboard.php"); exit; }

$alert = null;

// delete
if (isset($_GET['delete']) && $_GET['delete'] !== '') {
  $id = (int)$_GET['delete'];
  mysqli_query($conn, "DELETE FROM bimbingan WHERE id_bimbingan='$id' AND nidn='$nidn'");
  $alert = "Catatan bimbingan berhasil dihapus.";
}

// create
if (isset($_POST['save'])) {
  $nim = mysqli_real_escape_string($conn, $_POST['nim'] ?? '');
  $topik = mysqli_real_escape_string($conn, $_POST['topik'] ?? '');
  $tanggal = mysqli_real_escape_string($conn, $_POST['tanggal'] ?? date('Y-m-d'));
  $catatan = mysqli_real_escape_string($conn, $_POST['catatan'] ?? '');

  mysqli_query($conn, "INSERT INTO bimbingan (nim, nidn, topik, tanggal, catatan) VALUES ('$nim', '$nidn', '$topik', '$tanggal', '$catatan')");
  $alert = "Catatan bimbingan berhasil ditambahkan.";
}

$mhs = mysqli_query($conn, "SELECT nim, nama FROM mahasiswa ORDER BY nim ASC");

$list = mysqli_query($conn, "
  SELECT b.id_bimbingan, b.nim, m.nama AS nama_mhs, b.topik, b.tanggal, b.catatan
  FROM bimbingan b
  LEFT JOIN mahasiswa m ON b.nim=m.nim
  WHERE b.nidn='$nidn'
  ORDER BY b.tanggal DESC, b.id_bimbingan DESC
");

include "../includes/layout_top.php";
?>
<?php include "../includes/sidebar.php"; ?>
<main class="main">
  <?php include "../includes/header.php"; ?>

  <div class="container">
    <?php if ($alert): ?><div class="alert alert--ok" style="margin-bottom:12px;"><?= esc($alert) ?></div><?php endif; ?>

    <div class="grid">
      <div class="panel" style="grid-column: span 5;">
        <div class="panel__header">
          <div>
            <div class="panel__title">Tambah Catatan</div>
            <div class="panel__desc">Catat hasil bimbingan per mahasiswa.</div>
          </div>
        </div>

        <form class="form" method="POST">
          <div class="field field--full">
            <div class="label">Mahasiswa</div>
            <select class="select" name="nim" required>
              <option value="">-- Pilih Mahasiswa --</option>
              <?php while($r=mysqli_fetch_assoc($mhs)): ?>
                <option value="<?= esc($r['nim']) ?>"><?= esc($r['nim']) ?> - <?= esc($r['nama']) ?></option>
              <?php endwhile; ?>
            </select>
          </div>

          <div class="field field--full">
            <div class="label">Topik</div>
            <input class="input" name="topik" placeholder="Contoh: Revisi Bab 2 / Progress Implementasi" required>
          </div>

          <div class="field">
            <div class="label">Tanggal</div>
            <input class="input" type="date" name="tanggal" value="<?= date('Y-m-d') ?>" required>
          </div>

          <div class="field field--full">
            <div class="label">Catatan</div>
            <textarea class="textarea" name="catatan" required></textarea>
          </div>

          <div class="field field--full actions">
            <button class="btn btn--primary" name="save" type="submit">Simpan</button>
          </div>
        </form>
      </div>

      <div class="panel" style="grid-column: span 7;">
        <div class="panel__header">
          <div>
            <div class="panel__title">Riwayat Bimbingan</div>
            <div class="panel__desc">Daftar catatan bimbingan yang sudah dibuat.</div>
          </div>
        </div>

        <table class="table">
          <thead>
            <tr><th>Tanggal</th><th>Mahasiswa</th><th>Topik</th><th>Catatan</th><th></th></tr>
          </thead>
          <tbody>
            <?php if ($list && mysqli_num_rows($list)>0): ?>
              <?php while($r=mysqli_fetch_assoc($list)): ?>
                <tr>
                  <td><?= esc($r['tanggal']) ?></td>
                  <td><?= esc($r['nim']) ?><div class="small"><?= esc($r['nama_mhs'] ?? '-') ?></div></td>
                  <td><?= esc($r['topik']) ?></td>
                  <td><?= esc($r['catatan']) ?></td>
                  <td>
                    <a class="btn btn--danger" href="?delete=<?= (int)$r['id_bimbingan'] ?>" onclick="return confirm('Hapus catatan ini?')">Hapus</a>
                  </td>
                </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr><td colspan="5" class="muted">Belum ada catatan bimbingan.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

    </div>
  </div>
</main>
<?php include "../includes/layout_bottom.php"; ?>
