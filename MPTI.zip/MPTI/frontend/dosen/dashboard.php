<?php
require_once "../includes/auth.php";
require_role('dosen');
require_once "../config/db.php";

$page_title = "Dashboard Dosen";
$asset_prefix = "../";
$menu_prefix = "../";
$logout_prefix = "../";

$id_user = (int)$_SESSION['id_user'];
$dosen = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM dosen WHERE id_user='$id_user' LIMIT 1"));
$nidn = $dosen['nidn'] ?? '';

$cnt_bimb = $nidn ? mysqli_num_rows(mysqli_query($conn, "SELECT id_bimbingan FROM bimbingan WHERE nidn='$nidn'")) : 0;
$cnt_nilai = $nidn ? mysqli_num_rows(mysqli_query($conn, "SELECT id_penilaian FROM penilaian WHERE nidn='$nidn'")) : 0;

$pending = mysqli_query($conn, "
  SELECT l.id_laporan, l.nim, m.nama AS nama_mhs, l.judul, l.tanggal_upload,
         (SELECT COUNT(*) FROM penilaian p WHERE p.id_laporan=l.id_laporan) AS sudah_dinilai
  FROM laporan l
  LEFT JOIN mahasiswa m ON l.nim=m.nim
  ORDER BY l.id_laporan DESC
  LIMIT 8
");

include "../includes/layout_top.php";
?>
<?php include "../includes/sidebar.php"; ?>
<main class="main">
  <?php include "../includes/header.php"; ?>

  <div class="container">
    <div class="grid">
      <div class="card"><div class="card__title">Nama Dosen</div><div class="card__value" style="font-size:18px;"><?= esc($dosen['nama'] ?? '-') ?></div><div class="badge">NIDN: <?= esc($nidn ?: '-') ?></div></div>
      <div class="card"><div class="card__title">Catatan Bimbingan</div><div class="card__value"><?= $cnt_bimb ?></div><div class="badge">Tabel bimbingan</div></div>
      <div class="card"><div class="card__title">Penilaian Dibuat</div><div class="card__value"><?= $cnt_nilai ?></div><div class="badge">Tabel penilaian</div></div>
      <div class="card"><div class="card__title">Aksi Cepat</div><div class="card__value" style="font-size:16px;">Menu</div><div class="badge">Penilaian & Bimbingan</div></div>

      <div class="panel">
        <div class="panel__header">
          <div>
            <div class="panel__title">Laporan Terbaru</div>
            <div class="panel__desc">Pilih laporan untuk dinilai melalui menu Penilaian.</div>
          </div>
          <div class="actions">
            <a class="btn btn--primary" href="penilaian.php">Buka Penilaian</a>
            <a class="btn btn--ghost" href="bimbingan.php">Catatan Bimbingan</a>
          </div>
        </div>

        <table class="table">
          <thead>
            <tr><th>ID</th><th>Mahasiswa</th><th>Judul</th><th>Tanggal</th><th>Status</th></tr>
          </thead>
          <tbody>
            <?php if ($pending && mysqli_num_rows($pending)>0): ?>
              <?php while($r=mysqli_fetch_assoc($pending)): ?>
                <tr>
                  <td>#<?= esc($r['id_laporan']) ?></td>
                  <td><?= esc($r['nim']) ?><div class="small"><?= esc($r['nama_mhs'] ?? '-') ?></div></td>
                  <td><?= esc($r['judul']) ?></td>
                  <td><?= esc($r['tanggal_upload']) ?></td>
                  <td>
                    <?php if ((int)$r['sudah_dinilai'] > 0): ?>
                      <span class="badge">Sudah dinilai</span>
                    <?php else: ?>
                      <span class="badge" style="border-color:rgba(255,176,32,.35);color:#ffd9a1;">Belum dinilai</span>
                    <?php endif; ?>
                  </td>
                </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr><td colspan="5" class="muted">Belum ada laporan.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

    </div>
  </div>
</main>
<?php include "../includes/layout_bottom.php"; ?>
