<?php
require_once "../includes/auth.php";
require_role('dosen');
require_once "../config/db.php";

$page_title = "Jadwal & Pengumuman";
$asset_prefix = "../";
$menu_prefix = "../";
$logout_prefix = "../";

$list = mysqli_query($conn, "SELECT * FROM jadwal_pengumuman ORDER BY tanggal DESC, id_jadwal DESC");

include "../includes/layout_top.php";
?>
<?php include "../includes/sidebar.php"; ?>
<main class="main">
  <?php include "../includes/header.php"; ?>

  <div class="container">
    <div class="grid">
      <div class="panel">
        <div class="panel__header">
          <div>
            <div class="panel__title">Jadwal & Pengumuman</div>
            <div class="panel__desc">Informasi yang dipublikasikan admin.</div>
          </div>
        </div>

        <table class="table">
          <thead><tr><th>Tanggal</th><th>Judul</th><th>Deskripsi</th></tr></thead>
          <tbody>
            <?php if ($list && mysqli_num_rows($list)>0): ?>
              <?php while($r=mysqli_fetch_assoc($list)): ?>
                <tr>
                  <td><?= esc($r['tanggal']) ?></td>
                  <td><?= esc($r['judul']) ?></td>
                  <td><?= esc($r['deskripsi']) ?></td>
                </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr><td colspan="3" class="muted">Belum ada data.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</main>
<?php include "../includes/layout_bottom.php"; ?>
