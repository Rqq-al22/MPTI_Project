<?php
require_once "../includes/auth.php";
require_role('dosen');
require_once "../config/db.php";

$page_title = "Penilaian Laporan";
$asset_prefix = "../";
$menu_prefix = "../";
$logout_prefix = "../";

$id_user = (int)$_SESSION['id_user'];
$dosen = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM dosen WHERE id_user='$id_user' LIMIT 1"));
$nidn = $dosen['nidn'] ?? '';
if (!$nidn) {
  header("Location: dashboard.php");
  exit;
}

$alert = null;

// Simpan nilai
if (isset($_POST['save_nilai'])) {
  $id_laporan = (int)($_POST['id_laporan'] ?? 0);
  $nilai = (int)($_POST['nilai'] ?? 0);
  $komentar = mysqli_real_escape_string($conn, $_POST['komentar'] ?? '');

  // cek sudah ada penilaian untuk laporan ini oleh dosen ini?
  $cek = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id_penilaian FROM penilaian WHERE id_laporan='$id_laporan' AND nidn='$nidn' LIMIT 1"));
  if ($cek) {
    $id_penilaian = (int)$cek['id_penilaian'];
    mysqli_query($conn, "UPDATE penilaian SET nilai='$nilai', komentar='$komentar' WHERE id_penilaian='$id_penilaian'");
    $alert = "Penilaian berhasil diperbarui.";
  } else {
    mysqli_query($conn, "INSERT INTO penilaian (id_laporan, nidn, nilai, komentar) VALUES ('$id_laporan', '$nidn', '$nilai', '$komentar')");
    $alert = "Penilaian berhasil disimpan.";
  }
}

// daftar laporan
$list = mysqli_query($conn, "
  SELECT l.id_laporan, l.nim, m.nama AS nama_mhs, l.judul, l.file_laporan, l.tanggal_upload,
         p.nilai, p.komentar
  FROM laporan l
  LEFT JOIN mahasiswa m ON l.nim=m.nim
  LEFT JOIN penilaian p ON p.id_laporan=l.id_laporan AND p.nidn='$nidn'
  ORDER BY l.id_laporan DESC
");

$selected = null;
if (isset($_GET['id']) && $_GET['id'] !== '') {
  $id = (int)$_GET['id'];
  $selected = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT l.id_laporan, l.nim, m.nama AS nama_mhs, l.judul, l.file_laporan, l.tanggal_upload,
           p.nilai, p.komentar
    FROM laporan l
    LEFT JOIN mahasiswa m ON l.nim=m.nim
    LEFT JOIN penilaian p ON p.id_laporan=l.id_laporan AND p.nidn='$nidn'
    WHERE l.id_laporan='$id'
    LIMIT 1
  "));
}

include "../includes/layout_top.php";
?>
<?php include "../includes/sidebar.php"; ?>
<main class="main">
  <?php include "../includes/header.php"; ?>

  <div class="container">
    <?php if ($alert): ?><div class="alert alert--ok" style="margin-bottom:12px;"><?= esc($alert) ?></div><?php endif; ?>

    <div class="grid">
      <div class="panel" style="grid-column: span 7;">
        <div class="panel__header">
          <div>
            <div class="panel__title">Daftar Laporan</div>
            <div class="panel__desc">Pilih salah satu laporan untuk memberi nilai.</div>
          </div>
        </div>

        <table class="table">
          <thead>
            <tr><th>ID</th><th>Mahasiswa</th><th>Judul</th><th>Status</th><th></th></tr>
          </thead>
          <tbody>
            <?php if ($list && mysqli_num_rows($list)>0): ?>
              <?php while($r=mysqli_fetch_assoc($list)): ?>
                <tr>
                  <td>#<?= esc($r['id_laporan']) ?></td>
                  <td><?= esc($r['nim']) ?><div class="small"><?= esc($r['nama_mhs'] ?? '-') ?></div></td>
                  <td><?= esc($r['judul']) ?></td>
                  <td>
                    <?php if ($r['nilai'] !== null): ?>
                      <span class="badge">Nilai: <?= esc($r['nilai']) ?></span>
                    <?php else: ?>
                      <span class="badge" style="border-color:rgba(255,176,32,.35);color:#ffd9a1;">Belum dinilai</span>
                    <?php endif; ?>
                  </td>
                  <td><a class="btn btn--ghost" href="?id=<?= (int)$r['id_laporan'] ?>">Pilih</a></td>
                </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr><td colspan="5" class="muted">Belum ada laporan.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      <div class="panel" style="grid-column: span 5;">
        <div class="panel__header">
          <div>
            <div class="panel__title">Form Penilaian</div>
            <div class="panel__desc">Isi nilai dan komentar untuk laporan terpilih.</div>
          </div>
        </div>

        <?php if (!$selected): ?>
          <div class="alert alert--warn">Silakan pilih laporan dari tabel di sebelah kiri.</div>
        <?php else: ?>
          <div class="alert" style="margin-bottom:12px;">
            <b>#<?= esc($selected['id_laporan']) ?></b> • <?= esc($selected['nim']) ?> (<?= esc($selected['nama_mhs'] ?? '-') ?>)
            <div class="muted" style="margin-top:6px;"><?= esc($selected['judul']) ?></div>
            <?php if (!empty($selected['file_laporan'])): ?>
              <div style="margin-top:10px;">
                <a class="btn btn--ghost" href="../uploads/<?= urlencode($selected['file_laporan']) ?>" target="_blank">Unduh File</a>
              </div>
            <?php endif; ?>
          </div>

          <form class="form" method="POST">
            <input type="hidden" name="id_laporan" value="<?= (int)$selected['id_laporan'] ?>">

            <div class="field field--full">
              <div class="label">Nilai (0 - 100)</div>
              <input class="input" type="number" name="nilai" min="0" max="100" value="<?= esc($selected['nilai'] ?? '') ?>" required>
            </div>

            <div class="field field--full">
              <div class="label">Komentar</div>
              <textarea class="textarea" name="komentar" required><?= esc($selected['komentar'] ?? '') ?></textarea>
            </div>

            <div class="field field--full actions">
              <button class="btn btn--primary" name="save_nilai" type="submit">Simpan Penilaian</button>
            </div>
          </form>
        <?php endif; ?>
      </div>

    </div>
  </div>
</main>
<?php include "../includes/layout_bottom.php"; ?>
