<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
?>
<header class="topbar">
  <button class="icon-btn" type="button" aria-label="Menu" data-toggle-sidebar>
    ☰
  </button>

  <div class="brand">
    <div class="brand__title">Sistem Informasi Rekap Kerja Praktik</div>
    <div class="brand__subtitle">mpti_db • role: <?= esc($_SESSION['role'] ?? '-') ?></div>
  </div>

  <div class="topbar__right">
    <div class="chip">
      <span class="chip__dot"></span>
      <?= esc($_SESSION['username'] ?? 'User') ?>
    </div>
    <a class="btn btn--ghost" href="<?= ($logout_prefix ?? "") ?>logout.php">Logout</a>
  </div>
</header>
