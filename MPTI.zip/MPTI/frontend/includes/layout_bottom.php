</div>
  <script>
    // Toggle sidebar (mobile)
    (function(){
      const btn = document.querySelector('[data-toggle-sidebar]');
      const app = document.querySelector('.app');
      if(btn && app){
        btn.addEventListener('click', ()=> app.classList.toggle('sidebar-open'));
      }
    })();
  </script>
</body>
</html>
