<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
$role = $_SESSION['role'] ?? '';
$prefix = $menu_prefix ?? "";
?>
<aside class="sidebar">
  <div class="sidebar__logo">
    <div class="logo-badge">KP</div>
    <div>
      <div class="sidebar__name">Rekap KP</div>
      <div class="sidebar__desc">Dashboard & Manajemen</div>
    </div>
  </div>

  <nav class="nav">
    <?php if ($role === 'admin'): ?>
      <a class="nav__item" href="<?= $prefix ?>admin/dashboard.php">Dashboard</a>
      <a class="nav__item" href="<?= $prefix ?>admin/mahasiswa.php">Data Mahasiswa</a>
      <a class="nav__item" href="<?= $prefix ?>admin/dosen.php">Data Dosen</a>
      <a class="nav__item" href="<?= $prefix ?>admin/pengumuman.php">Jadwal & Pengumuman</a>
    <?php elseif ($role === 'dosen'): ?>
      <a class="nav__item" href="<?= $prefix ?>dosen/dashboard.php">Dashboard</a>
      <a class="nav__item" href="<?= $prefix ?>dosen/penilaian.php">Penilaian Laporan</a>
      <a class="nav__item" href="<?= $prefix ?>dosen/bimbingan.php">Bimbingan</a>
      <a class="nav__item" href="<?= $prefix ?>dosen/pengumuman.php">Jadwal & Pengumuman</a>
    <?php elseif ($role === 'mahasiswa'): ?>
      <a class="nav__item" href="<?= $prefix ?>mahasiswa/dashboard.php">Dashboard</a>
      <a class="nav__item" href="<?= $prefix ?>mahasiswa/presensi.php">Presensi</a>
      <a class="nav__item" href="<?= $prefix ?>mahasiswa/laporan.php">Laporan</a>
      <a class="nav__item" href="<?= $prefix ?>mahasiswa/pengumuman.php">Jadwal & Pengumuman</a>
    <?php else: ?>
      <a class="nav__item" href="<?= $prefix ?>index.php">Login</a>
    <?php endif; ?>
  </nav>

  <div class="sidebar__footer">
    <div class="muted">© <?= date('Y') ?> Rekap KP</div>
  </div>
</aside>
