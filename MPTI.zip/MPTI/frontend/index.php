<?php
session_start();
if (isset($_SESSION['id_user'])) {
    $r = $_SESSION['role'] ?? '';
    if ($r === 'admin') header("Location: admin/dashboard.php");
    elseif ($r === 'dosen') header("Location: dosen/dashboard.php");
    else header("Location: mahasiswa/dashboard.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>Login • Rekap Kerja Praktik</title>
  <link rel="stylesheet" href="assets/css/venus.css">
</head>
<body>
  <div class="login-wrap">
    <div class="login-card">
      <h2 style = "text-align: center">Login </h2>
      <h1 style = "text-align: center">Sistem Informasi Rekap Kerja Praktik</h1>
    

      <?php if (isset($_GET['err'])): ?>
        <div class="alert alert--err" style="margin-top:14px;"><?= htmlspecialchars($_GET['err']) ?></div>
      <?php endif; ?>

      <form class="login-grid" method="POST" action="auth/login_process.php">
        <div>
          <div class="label">Username</div>
          <input class="input" name="username" autocomplete="username" required />
        </div>
        <div>
          <div class="label">Password</div>
          <input class="input" type="password" name="password" autocomplete="current-password" required />
        </div>
        <button class="btn btn--primary" type="submit">Masuk</button>
      </form>

      
    </div>
  </div>
</body>
</html>
