<?php
require_once "../includes/auth.php";
require_role('mahasiswa');
require_once "../config/db.php";

$page_title = "Dashboard Mahasiswa";
$asset_prefix = "../";
$menu_prefix = "../";
$logout_prefix = "../";

$id_user = (int)$_SESSION['id_user'];
$mhs = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM mahasiswa WHERE id_user='$id_user' LIMIT 1"));
$nim = $mhs['nim'] ?? '';

$cnt_presensi = $nim ? mysqli_num_rows(mysqli_query($conn, "SELECT id_presensi FROM presensi WHERE nim='$nim'")) : 0;
$cnt_laporan  = $nim ? mysqli_num_rows(mysqli_query($conn, "SELECT id_laporan FROM laporan WHERE nim='$nim'")) : 0;

$last_nilai = null;
if ($nim) {
  $last_nilai = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT p.nilai, p.komentar, p.id_laporan
    FROM penilaian p
    JOIN laporan l ON p.id_laporan=l.id_laporan
    WHERE l.nim='$nim'
    ORDER BY p.id_penilaian DESC
    LIMIT 1
  "));
}

$latest_peng = mysqli_query($conn, "SELECT * FROM jadwal_pengumuman ORDER BY tanggal DESC, id_jadwal DESC LIMIT 5");

include "../includes/layout_top.php";
?>
<?php include "../includes/sidebar.php"; ?>
<main class="main">
  <?php include "../includes/header.php"; ?>

  <div class="container">
    <div class="grid">
      <div class="card"><div class="card__title">NIM</div><div class="card__value" style="font-size:18px;"><?= esc($nim ?: '-') ?></div><div class="badge"><?= esc($mhs['nama'] ?? '-') ?></div></div>
      <div class="card"><div class="card__title">Total Presensi</div><div class="card__value"><?= $cnt_presensi ?></div><div class="badge">Menu Presensi</div></div>
      <div class="card"><div class="card__title">Total Laporan</div><div class="card__value"><?= $cnt_laporan ?></div><div class="badge">Menu Laporan</div></div>
      <div class="card"><div class="card__title">Nilai Terakhir</div><div class="card__value"><?= $last_nilai ? esc($last_nilai['nilai']) : '-' ?></div><div class="badge">Dari dosen</div></div>

      <div class="panel">
        <div class="panel__header">
          <div>
            <div class="panel__title">Pengumuman Terbaru</div>
            <div class="panel__desc">Jadwal dan informasi penting dari admin.</div>
          </div>
          <div class="actions">
            <a class="btn btn--ghost" href="pengumuman.php">Lihat Semua</a>
          </div>
        </div>

        <table class="table">
          <thead><tr><th>Tanggal</th><th>Judul</th><th>Deskripsi</th></tr></thead>
          <tbody>
            <?php if ($latest_peng && mysqli_num_rows($latest_peng)>0): ?>
              <?php while($r=mysqli_fetch_assoc($latest_peng)): ?>
                <tr>
                  <td><?= esc($r['tanggal']) ?></td>
                  <td><?= esc($r['judul']) ?></td>
                  <td><?= esc($r['deskripsi']) ?></td>
                </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr><td colspan="3" class="muted">Belum ada pengumuman.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

    </div>
  </div>
</main>
<?php include "../includes/layout_bottom.php"; ?>
