<?php
require_once "../includes/auth.php";
require_role('mahasiswa');
require_once "../config/db.php";

$page_title = "Laporan";
$asset_prefix = "../";
$menu_prefix = "../";
$logout_prefix = "../";

$id_user = (int)$_SESSION['id_user'];
$mhs = mysqli_fetch_assoc(mysqli_query($conn, "SELECT nim, nama FROM mahasiswa WHERE id_user='$id_user' LIMIT 1"));
$nim = $mhs['nim'] ?? '';

$alert = null;

if (isset($_POST['upload']) && $nim) {
  $judul = mysqli_real_escape_string($conn, $_POST['judul'] ?? '');

  if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
    $alert = "Upload gagal. Pastikan memilih file.";
  } else {
    $fname = $_FILES['file']['name'];
    $ext = strtolower(pathinfo($fname, PATHINFO_EXTENSION));
    $allowed = ['pdf','doc','docx','zip','rar'];
    if (!in_array($ext, $allowed)) {
      $alert = "Format file tidak diizinkan. Gunakan: PDF/DOC/DOCX/ZIP/RAR.";
    } else {
      $safe = preg_replace('/[^a-zA-Z0-9._-]/','_', $fname);
      $newname = $nim . "_" . date("Ymd_His") . "_" . $safe;
      $dest = "../uploads/" . $newname;

      if (move_uploaded_file($_FILES['file']['tmp_name'], $dest)) {
        $tgl = date('Y-m-d');
        mysqli_query($conn, "INSERT INTO laporan (nim, judul, file_laporan, tanggal_upload) VALUES ('$nim', '$judul', '$newname', '$tgl')");
        $alert = "Laporan berhasil diunggah.";
      } else {
        $alert = "Gagal memindahkan file upload. Cek izin folder uploads.";
      }
    }
  }
}

$list = $nim ? mysqli_query($conn, "
  SELECT l.id_laporan, l.judul, l.file_laporan, l.tanggal_upload,
         p.nilai, p.komentar, d.nama AS nama_dosen
  FROM laporan l
  LEFT JOIN penilaian p ON p.id_laporan = l.id_laporan
  LEFT JOIN dosen d ON p.nidn = d.nidn
  WHERE l.nim='$nim'
  ORDER BY l.id_laporan DESC
") : null;

include "../includes/layout_top.php";
?>
<?php include "../includes/sidebar.php"; ?>
<main class="main">
  <?php include "../includes/header.php"; ?>

  <div class="container">
    <?php if ($alert): ?><div class="alert alert--ok" style="margin-bottom:12px;"><?= esc($alert) ?></div><?php endif; ?>

    <div class="grid">
      <div class="panel" style="grid-column: span 5;">
        <div class="panel__header">
          <div>
            <div class="panel__title">Upload Laporan</div>
            <div class="panel__desc">NIM: <?= esc($nim ?: '-') ?> • <?= esc($mhs['nama'] ?? '-') ?></div>
          </div>
        </div>

        <?php if (!$nim): ?>
          <div class="alert alert--err">Data mahasiswa belum terhubung ke akun ini. Hubungi admin.</div>
        <?php else: ?>
          <form class="form" method="POST" enctype="multipart/form-data">
            <div class="field field--full">
              <div class="label">Judul Laporan</div>
              <input class="input" name="judul" placeholder="Contoh: Laporan Minggu 1" required>
            </div>
            <div class="field field--full">
              <div class="label">File Laporan</div>
              <input class="input" type="file" name="file" required>
              <div class="muted" style="margin-top:8px;font-size:12px;">Format: PDF/DOC/DOCX/ZIP/RAR</div>
            </div>

            <div class="field field--full actions">
              <button class="btn btn--primary" name="upload" type="submit">Upload</button>
            </div>
          </form>
        <?php endif; ?>
      </div>

      <div class="panel" style="grid-column: span 7;">
        <div class="panel__header">
          <div>
            <div class="panel__title">Riwayat Laporan</div>
            <div class="panel__desc">Laporan yang sudah diunggah dan status penilaian.</div>
          </div>
        </div>

        <table class="table">
          <thead><tr><th>ID</th><th>Judul</th><th>Tanggal</th><th>File</th><th>Nilai</th></tr></thead>
          <tbody>
            <?php if ($list && mysqli_num_rows($list)>0): ?>
              <?php while($r=mysqli_fetch_assoc($list)): ?>
                <tr>
                  <td>#<?= esc($r['id_laporan']) ?></td>
                  <td><?= esc($r['judul']) ?><div class="small"><?= $r['nama_dosen'] ? "Dosen: ".esc($r['nama_dosen']) : "" ?></div></td>
                  <td><?= esc($r['tanggal_upload']) ?></td>
                  <td>
                    <?php if (!empty($r['file_laporan'])): ?>
                      <a class="btn btn--ghost" href="../uploads/<?= urlencode($r['file_laporan']) ?>" target="_blank">Unduh</a>
                    <?php else: ?>
                      <span class="muted">-</span>
                    <?php endif; ?>
                  </td>
                  <td>
                    <?php if ($r['nilai'] !== null): ?>
                      <span class="badge"><?= esc($r['nilai']) ?></span>
                      <div class="small"><?= esc($r['komentar'] ?? '') ?></div>
                    <?php else: ?>
                      <span class="badge" style="border-color:rgba(255,176,32,.35);color:#ffd9a1;">Belum dinilai</span>
                    <?php endif; ?>
                  </td>
                </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr><td colspan="5" class="muted">Belum ada laporan.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</main>
<?php include "../includes/layout_bottom.php"; ?>
