<?php
require_once "../includes/auth.php";
require_role('mahasiswa');
require_once "../config/db.php";

$page_title = "Presensi";
$asset_prefix = "../";
$menu_prefix = "../";
$logout_prefix = "../";

$id_user = (int)$_SESSION['id_user'];
$mhs = mysqli_fetch_assoc(mysqli_query($conn, "SELECT nim, nama FROM mahasiswa WHERE id_user='$id_user' LIMIT 1"));
$nim = $mhs['nim'] ?? '';

$alert = null;

if (isset($_POST['save']) && $nim) {
  $tanggal = mysqli_real_escape_string($conn, $_POST['tanggal'] ?? date('Y-m-d'));
  $status = mysqli_real_escape_string($conn, $_POST['status'] ?? 'Hadir');

  // cegah dobel tanggal
  $cek = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id_presensi FROM presensi WHERE nim='$nim' AND tanggal='$tanggal' LIMIT 1"));
  if ($cek) {
    $alert = "Presensi pada tanggal tersebut sudah ada.";
  } else {
    mysqli_query($conn, "INSERT INTO presensi (nim, tanggal, status) VALUES ('$nim', '$tanggal', '$status')");
    $alert = "Presensi berhasil disimpan.";
  }
}

$list = $nim ? mysqli_query($conn, "SELECT * FROM presensi WHERE nim='$nim' ORDER BY tanggal DESC, id_presensi DESC") : null;

include "../includes/layout_top.php";
?>
<?php include "../includes/sidebar.php"; ?>
<main class="main">
  <?php include "../includes/header.php"; ?>

  <div class="container">
    <?php if ($alert): ?><div class="alert alert--ok" style="margin-bottom:12px;"><?= esc($alert) ?></div><?php endif; ?>

    <div class="grid">
      <div class="panel" style="grid-column: span 5;">
        <div class="panel__header">
          <div>
            <div class="panel__title">Input Presensi</div>
            <div class="panel__desc">NIM: <?= esc($nim ?: '-') ?> • <?= esc($mhs['nama'] ?? '-') ?></div>
          </div>
        </div>

        <?php if (!$nim): ?>
          <div class="alert alert--err">Data mahasiswa belum terhubung ke akun ini. Hubungi admin.</div>
        <?php else: ?>
          <form class="form" method="POST">
            <div class="field field--full">
              <div class="label">Tanggal</div>
              <input class="input" type="date" name="tanggal" value="<?= date('Y-m-d') ?>" required>
            </div>
            <div class="field field--full">
              <div class="label">Status</div>
              <select class="select" name="status" required>
                <option value="Hadir">Hadir</option>
                <option value="Izin">Izin</option>
                <option value="Alpha">Alpha</option>
              </select>
            </div>
            <div class="field field--full actions">
              <button class="btn btn--primary" name="save" type="submit">Simpan Presensi</button>
            </div>
          </form>
        <?php endif; ?>
      </div>

      <div class="panel" style="grid-column: span 7;">
        <div class="panel__header">
          <div>
            <div class="panel__title">Riwayat Presensi</div>
            <div class="panel__desc">Daftar presensi yang sudah tercatat.</div>
          </div>
        </div>

        <table class="table">
          <thead><tr><th>Tanggal</th><th>Status</th></tr></thead>
          <tbody>
            <?php if ($list && mysqli_num_rows($list)>0): ?>
              <?php while($r=mysqli_fetch_assoc($list)): ?>
                <tr>
                  <td><?= esc($r['tanggal']) ?></td>
                  <td><?= esc($r['status']) ?></td>
                </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr><td colspan="2" class="muted">Belum ada presensi.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</main>
<?php include "../includes/layout_bottom.php"; ?>
